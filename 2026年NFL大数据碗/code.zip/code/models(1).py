import torch
import torch.nn as nn



class JointSeqModel(nn.Module):
    """
    JointSeqModel：把“传球前最后 window_size 帧”的历史轨迹 -> 编码成一个全局表示 -> 输出未来位移序列。

    这个模型解决的核心问题：
    - 输入是固定长度的历史窗口：x.shape = [B, T, F]
      B: batch size
      T: 历史窗口长度（例如 10 帧）
      F: 每帧特征维度（手工特征 + 几何特征 + 交互特征等）
    - 输出是固定上限长度的未来轨迹（相对位移）：pred.shape = [B, H, 2]
      H: horizon（统一预测步数上限，比如 94）
      2: (dx, dy)

    设计思路分三步：
    1) GRU：把时间序列逐帧编码成隐状态序列 h = [B, T, 128]
       - 每个时间步的 h_t 都包含“截至该时刻”的历史信息
       - 相比直接用最后一个 h_T，保留整段 h 更利于后续做注意力汇聚
    2) Attention Pooling：用一个“可学习 query”从整段 h 中提取一个全局向量 ctx = [B, 1, 128]
       - 类似 Transformer 里的 [CLS] token：模型自己学习“该关注哪些帧”
       - 比简单 mean/max pooling 更灵活：能学到“最后几帧更关键”或“某些帧变化更显著”
    3) Head：把 ctx 映射为 horizon*2 个数，再 reshape 成 [B, H, 2]
       - 这里 head 的输出被解释为“每一步的增量（delta）”，然后用 cumsum 变成“相对位移轨迹”
       - 这样做的好处：
         * 预测更稳定（把复杂轨迹拆成一小步一小步）
         * 与训练目标 dx/dy（相对最后输入帧的位置）天然对齐

    最后：forward 返回 torch.cumsum(out, dim=1)，代表从 0 开始累加得到整条未来相对位移曲线。
    """

    def __init__(self, input_dim, horizon):
        super().__init__()

        # - input:  [B, T, input_dim]
        # - output: [B, T, hidden_dim]
        self.gru = nn.GRU(
            input_dim,
            128,
            num_layers=2,
            batch_first=True,
            dropout=0.1
        )

        self.pool_ln = nn.LayerNorm(128)

        # - query: [B, 1, 128]
        # - key/value: [B, T, 128]
        # 输出 ctx: [B, 1, 128]
        self.pool_attn = nn.MultiheadAttention(
            128,
            num_heads=4,
            batch_first=True
        )

        # 可学习的 query 向量（相当于一个“全局提问者”）
        # 初始随机，训练中会学到：怎样提问才能从历史序列中抽取对未来最有用的信息
        self.pool_query = nn.Parameter(torch.randn(1, 1, 128))

        # 回归头：把全局向量 -> 未来 H 步 * 2 维（dx, dy）增量
        # - 先升维到 256，加非线性（GELU），再 dropout 防过拟合，最后映射到 horizon*2
        self.head = nn.Sequential(
            nn.Linear(128, 256),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(256, horizon * 2)
        )

    def forward(self, x):
        # x: [B, T, F]
        # h: [B, T, 128]  （每帧对应一个隐状态向量）
        h, _ = self.gru(x)

        # B: batch size
        B = h.size(0)

        # q: [B, 1, 128]  （把同一个可学习 query 复制到每个样本）
        q = self.pool_query.expand(B, -1, -1)

        # 注意力池化：让 query 去“关注”历史序列 h
        # - key/value 使用 LayerNorm(h) 提升数值稳定性
        # ctx: [B, 1, 128]
        ctx, _ = self.pool_attn(q, self.pool_ln(h), self.pool_ln(h))

        # 回归输出：
        # out: [B, horizon*2] -> reshape 成 [B, horizon, 2]
        out = self.head(ctx.squeeze(1))
        out = out.view(B, -1, 2)

        # 关键：把“每步增量”累加成“相对位移轨迹”
        # pred[t] = delta[0] + delta[1] + ... + delta[t]
        # 返回: [B, horizon, 2]
        return torch.cumsum(out, dim=1)


# ============================================================================
# 损失函数（带时间衰减的 Huber Loss）
# ============================================================================

class TemporalHuber(nn.Module):
    """
    TemporalHuber：在“未来序列预测”场景中更稳健的损失函数。

    为什么不用普通 MSE？
    - 未来轨迹里可能存在：追踪噪声、极端动作、少数异常点
    - MSE 对大误差惩罚过强，容易被少量 outlier 主导训练
    - Huber 在小误差区间像 MSE（平滑、可微、收敛快），大误差区间像 MAE（更抗异常）

    再加上“时间衰减”是为什么？
    - 越靠近出手后的短期（例如前 1 秒）的轨迹通常更可预测、更重要
    - 越远未来不确定性更大，强行拟合可能导致模型不稳定
    - 因此给远未来更小权重：w_t = exp(-time_decay * t)

    输入输出约定：
    - pred:   [B, L, 2]  模型预测的相对位移（dx, dy）
    - target: [B, L, 2]  真实相对位移
    - mask:   [B, L]     有效步长（因为每个球员未来帧数 L_i 不一样，padding 的部分 mask=0）

    最终返回：只在 mask=1 的有效位置上计算加权平均损失。
    """

    def __init__(self, delta=0.5, time_decay=0.03):
        super().__init__()

        # delta：Huber 的“转折点”
        # - |err| <= delta：用 0.5 * err^2（像 MSE）
        # - |err| >  delta：用 delta*(|err|-0.5*delta)（像 MAE，线性增长）
        self.delta = delta

        # time_decay：时间衰减强度（越大表示越“偏重近未来”）
        self.time_decay = time_decay

    def forward(self, pred, target, mask):
        # pred/target: [B, L, 2]
        # mask: [B, L]

        # 误差与绝对误差
        err = pred - target
        abs_err = torch.abs(err)

        # 逐元素 Huber：输出形状仍为 [B, L, 2]
        huber = torch.where(
            abs_err <= self.delta,
            0.5 * err * err,                          # 小误差：二次项（更平滑）
            self.delta * (abs_err - 0.5 * self.delta) # 大误差：线性项（更鲁棒）
        )

        # 时间衰减：对不同未来步 t 赋予不同权重
        # weight: [1, L, 1]，广播到 [B, L, 2]
        # 同时也要作用到 mask（否则 padding 位置会被错误加权）
        if self.time_decay > 0:
            L = pred.size(1)
            t = torch.arange(L, device=pred.device).float()
            weight = torch.exp(-self.time_decay * t).view(1, L, 1)

            huber = huber * weight

            # mask 原本是 [B, L]，这里扩展到 [B, L, 1] 以便与 huber 对齐
            # 并同步乘以 weight（实现“有效步长 + 时间衰减”双重筛选）
            mask = mask.unsqueeze(-1) * weight

        # 只在有效区域求和，再除以有效权重和（做加权平均）
        # +1e-8 防止极端情况下除 0
        return (huber * mask).sum() / (mask.sum() + 1e-8)

