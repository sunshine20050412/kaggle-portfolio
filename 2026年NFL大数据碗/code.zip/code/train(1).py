import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm.auto import tqdm
import warnings
import os
import pickle

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from sklearn.cluster import KMeans
from multiprocessing import Pool as MultiprocessingPool, cpu_count

from utils import set_seed
from models import JointSeqModel, TemporalHuber
from data_fe import prepare_sequences_geometric

warnings.filterwarnings('ignore')  # 关闭告警输出，避免训练日志被打断

class Config:
    DATA_DIR = Path("./input/nfl-big-data-bowl-2026-prediction/")
    OUTPUT_DIR = Path("./outputs")  # 本地输出目录
    OUTPUT_DIR.mkdir(exist_ok=True)  # 若不存在则创建输出目录
    
    SEED = 42
    N_FOLDS = 5
    BATCH_SIZE = 256
    EPOCHS = 200
    PATIENCE = 30  # 早停耐心：验证集连续不提升的 epoch 数阈值
    LEARNING_RATE = 1e-3  # AdamW 初始学习率
    
    WINDOW_SIZE = 10  # 输入序列长度：传球前最近 window_size 帧作为历史上下文
    HIDDEN_DIM = 128  # GRU 隐层维度
    MAX_FUTURE_HORIZON = 94  # 统一预测步长上限（按比赛最大 num_frames_output 对齐）
        
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 训练/推理设备选择

set_seed(Config.SEED)



def prepare_targets(batch_dx, batch_dy, max_h):
    '''
    目标：把一批样本中“未来位移序列”(dx, dy) 的不定长序列，统一 pad 到同一长度 max_h，
         同时返回 mask 标记哪些时间步是真实有效的（避免 pad 的 0 参与 loss）。
    
    输入:
      batch_dx: list[np.ndarray]，长度 = B，每个元素是该样本未来每一帧的 dx 序列（长度 Li 不同）
      batch_dy: list[np.ndarray]，长度 = B，每个元素是该样本未来每一帧的 dy 序列（长度 Li 不同）
      max_h:    int，统一的预测步长上限（horizon），所有样本都会 pad 到这个长度
    
    输出:
      targets: [B, H, 2]，每个时间步的 (dx, dy)，不足部分用 0 补齐
      masks:   [B, H]，有效步长为 1，无效（pad）步长为 0，用于 loss 只计算有效步
    '''

    tensors_x, tensors_y, masks = [], [], []  # 分别收集每个样本 pad 后的 dx、dy，以及对应 mask

    # 逐样本处理：对不定长序列 pad，并构造 mask
    for dx, dy in zip(batch_dx, batch_dy):
        L = len(dx)  # 该样本真实未来序列长度（=需要预测的帧数）

        # 将 dx / dy pad 到 max_h：真实部分保留，后面补 0
        # 注意：补 0 只是占位，真正训练时会用 mask 排除这些位置
        padded_x = np.pad(dx, (0, max_h - L), constant_values=0).astype(np.float32)
        padded_y = np.pad(dy, (0, max_h - L), constant_values=0).astype(np.float32)

        # mask: 前 L 步为 1（有效），后 max_h-L 步为 0（无效/pad）
        mask = np.zeros(max_h, dtype=np.float32)
        mask[:L] = 1.0

        # 转成 torch tensor，方便后续 batch stack
        tensors_x.append(torch.tensor(padded_x))
        tensors_y.append(torch.tensor(padded_y))
        masks.append(torch.tensor(mask))

    # 将 dx 和 dy 合并到最后一维，得到 targets: [B, H, 2]
    # stack(tensors_x) -> [B, H]，stack(tensors_y) -> [B, H]
    # 再 stack 到 dim=-1 -> [B, H, 2]，其中 2 对应 (dx, dy)
    targets = torch.stack([torch.stack(tensors_x), torch.stack(tensors_y)], dim=-1)

    # masks stack 后为 [B, H]
    return targets, torch.stack(masks)  # targets: [B,H,2]，masks: [B,H]


def train_model(X_train, y_train_dx, y_train_dy, X_val, y_val_dx, y_val_dy,
                input_dim, horizon, config):
    '''
    目标：训练一个“输入传球前历史窗口序列 -> 输出传球后未来位移序列(dx, dy)”的序列模型（JointSeqModel）
    核心点：
      1) 未来序列长度不一致：用 prepare_targets pad + mask
      2) 训练效率：提前把 numpy 数据打包成 tensor batch（减少每个 epoch 的 CPU 处理开销）
      3) 稳定训练：Huber + 时间衰减、AdamW、梯度裁剪、ReduceLROnPlateau、Early stopping
    
    输入（这里均已是“单样本序列”的 list）:
      X_train: list[np.ndarray]，长度 N_tr，每个元素 shape = [T, F]
      y_train_dx / y_train_dy: list[np.ndarray]，长度 N_tr，每个元素长度 Li（未来步数不定）
      X_val / y_val_dx / y_val_dy: 验证集同理
      input_dim: F（特征维度）
      horizon: H（统一预测的最大未来步长，即 pad 后长度）
    
    输出:
      model: 训练完成并回滚到“验证集最优”权重的模型
      best_loss: 最佳验证损失（用于外层记录）
    '''

    device = config.DEVICE  # 训练设备：cuda / cpu

    # 模型输出约定：pred shape = [B, H, 2]，预测每个未来时间步的 (dx, dy)
    model = JointSeqModel(input_dim, horizon).to(device)  # 初始化模型并放到 device

    # TemporalHuber：Huber 损失 + 时间衰减（越远未来可能权重更小/或更大，取决于实现）
    # mask 会用于只计算真实有效的未来步长（排除 pad）
    criterion = TemporalHuber(delta=0.5, time_decay=0.03)

    optimizer = torch.optim.AdamW(model.parameters(), lr=config.LEARNING_RATE, weight_decay=1e-5)

    # ReduceLROnPlateau：验证损失若在 patience 个 epoch 内无改善，则学习率乘以 factor
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, patience=5, factor=0.5, verbose=False
    )

    # -------------------------
    # 关键优化：预先构建 train/val 的批次（tensor），减少每个 epoch 的数据准备时间
    # -------------------------
    train_batches = []
    for i in range(0, len(X_train), config.BATCH_SIZE):
        end = min(i + config.BATCH_SIZE, len(X_train))

        # 将该 batch 的输入序列堆叠成 [B, T, F]
        bx = torch.tensor(np.stack(X_train[i:end]).astype(np.float32))

        # 将该 batch 的不定长目标序列 pad 到 horizon，并生成 mask
        # by: [B, H, 2]，bm: [B, H]
        by, bm = prepare_targets(
            [y_train_dx[j] for j in range(i, end)],
            [y_train_dy[j] for j in range(i, end)],
            horizon
        )
        train_batches.append((bx, by, bm))

    val_batches = []
    for i in range(0, len(X_val), config.BATCH_SIZE):
        end = min(i + config.BATCH_SIZE, len(X_val))
        bx = torch.tensor(np.stack(X_val[i:end]).astype(np.float32))
        by, bm = prepare_targets(
            [y_val_dx[j] for j in range(i, end)],
            [y_val_dy[j] for j in range(i, end)],
            horizon
        )
        val_batches.append((bx, by, bm))

    # Early stopping 相关变量：
    #   best_loss: 当前最好的验证损失
    #   best_state: 对应最优模型权重（保存一份 CPU 上的拷贝，防止后续训练覆盖）
    #   bad: 连续多少个 epoch 验证集没有变好
    best_loss, best_state, bad = float('inf'), None, 0

    # -------------------------
    # 训练主循环：epoch 级训练 + 验证
    # -------------------------
    for epoch in range(1, config.EPOCHS + 1):
        # ---- Train ----
        model.train()
        train_losses = []

        for bx, by, bm in train_batches:
            # 迁移到 device
            bx, by, bm = bx.to(device), by.to(device), bm.to(device)

            # 前向：输出 pred [B, H, 2]（未来每步 dx, dy）
            pred = model(bx)

            # loss：只在 bm=1 的有效时间步上计算（pad 的部分不会影响梯度）
            loss = criterion(pred, by, bm)

            # 反向传播标准流程
            optimizer.zero_grad()
            loss.backward()

            # 梯度裁剪：限制梯度范数，防止 RNN/GRU 类模型梯度爆炸导致训练不稳定
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            optimizer.step()
            train_losses.append(loss.item())

        # ---- Validation ----
        model.eval()
        val_losses = []
        with torch.no_grad():
            for bx, by, bm in val_batches:
                bx, by, bm = bx.to(device), by.to(device), bm.to(device)
                pred = model(bx)
                val_losses.append(criterion(pred, by, bm).item())

        # epoch 平均损失（便于观察曲线稳定性）
        train_loss, val_loss = np.mean(train_losses), np.mean(val_losses)

        # 根据验证集表现调整学习率（plateau 则降 LR）
        scheduler.step(val_loss)

        # 每 10 个 epoch 打印一次日志，避免输出过多
        if epoch % 10 == 0:
            print(f"  Epoch {epoch}: train={train_loss:.4f}, val={val_loss:.4f}")

        # ---- 保存最优模型（以 val_loss 为准）----
        if val_loss < best_loss:
            best_loss = val_loss

            # 保存一份“当前最优”的 state_dict（转到 CPU + clone，确保后续训练不影响保存结果）
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            bad = 0
        else:
            bad += 1

            # Early stopping：连续 PATIENCE 个 epoch 没提升就停止训练
            if bad >= config.PATIENCE:
                print(f"  Early stop at epoch {epoch}")
                break

    # 训练结束后，回滚到验证集最优权重（而不是最后一个 epoch 的权重）
    if best_state:
        model.load_state_dict(best_state)

    return model, best_loss


config = Config()  # 读取配置

# 加载训练/测试数据（训练按周分文件）
print("\n[1/3] Loading data...")
train_input_files = [config.DATA_DIR / f"train/input_2023_w{w:02d}.csv" for w in range(1, 19)]
train_output_files = [config.DATA_DIR / f"train/output_2023_w{w:02d}.csv" for w in range(1, 19)]
train_input = pd.concat([pd.read_csv(f) for f in train_input_files if f.exists()])
train_output = pd.concat([pd.read_csv(f) for f in train_output_files if f.exists()])

print(f"✓ Train input: {train_input.shape}, Train output: {train_output.shape}")

# 构造训练序列与目标（融合几何特征）
print("\n[2/3] Preparing geometric sequences...")
sequences, targets_dx, targets_dy, targets_frame_ids, sequence_ids, geo_x, geo_y, route_kmeans, route_scaler = prepare_sequences_geometric(
    train_input, train_output, is_training=True, window_size=config.WINDOW_SIZE
)

# save route_kmeans and route_scaler for inference
with open(config.OUTPUT_DIR / "route_kmeans_scaler.pkl", "wb") as f:
    pickle.dump({"route_kmeans": route_kmeans, "route_scaler": route_scaler}, f)


sequences = list(sequences)  # 转 list 便于按索引切分 fold
targets_dx = list(targets_dx)
targets_dy = list(targets_dy)

# 交叉验证训练：按 game_id 分组，避免同一比赛泄漏到验证
print("\n[3/3] Training geometric models...")
groups = np.array([d['game_id'] for d in sequence_ids])
gkf = GroupKFold(n_splits=config.N_FOLDS)

models, scalers = [], []  # 每折保存一个模型与对应的特征标准化器

for fold, (tr, va) in enumerate(gkf.split(sequences, groups=groups), 1):
    print(f"\n{'='*60}")
    print(f"Fold {fold}/{config.N_FOLDS}")
    print(f"{'='*60}")
    
    X_tr = [sequences[i] for i in tr]  # 训练序列列表，每个元素 [T,F]
    X_va = [sequences[i] for i in va]  # 验证序列列表
    y_tr_dx = [targets_dx[i] for i in tr]  # 训练 dx 目标（不定长）
    y_va_dx = [targets_dx[i] for i in va]
    y_tr_dy = [targets_dy[i] for i in tr]  # 训练 dy 目标（不定长）
    y_va_dy = [targets_dy[i] for i in va]
    
    # 标准化：按训练集所有时间步堆叠拟合，避免验证信息泄漏
    scaler = StandardScaler()
    scaler.fit(np.vstack([s for s in X_tr]))
    
    # 对每个序列逐帧标准化（保持 [T,F] 形状不变）
    X_tr_sc = [scaler.transform(s) for s in X_tr]
    X_va_sc = [scaler.transform(s) for s in X_va]
    
    # 训练该折模型
    model, loss = train_model(
        X_tr_sc, y_tr_dx, y_tr_dy,
        X_va_sc, y_va_dx, y_va_dy,
        X_tr[0].shape[-1], config.MAX_FUTURE_HORIZON, config
    )
    
    models.append(model)  # 保存折模型
    scalers.append(scaler)  # 保存折 scaler
    
    print(f"\n✓ Fold {fold} - Loss: {loss:.5f}")


# 保存models和scalers到本地
with open(config.OUTPUT_DIR / "exp_models_scalers.pkl", "wb") as f:
    pickle.dump({"models": models, "scalers": scalers}, f)