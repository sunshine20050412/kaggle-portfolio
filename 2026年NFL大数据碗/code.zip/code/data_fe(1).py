import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from tqdm import tqdm


# ============================================================================
# 几何基线
# ============================================================================
def compute_geometric_endpoint(df):
    """
    目标：为每一行（球员在“传球前某一帧”的状态）构造一个“几何/规则推断的终点”。
    ----------------------------------------------------------------------
    为什么要做这个？
    - 这场比赛要预测“球出手后、球在空中期间”的球员轨迹。
    - 纯神经网络直接预测绝对位置，学习难度大、泛化不稳。
    - 所以先用一套“可解释的规则”给出一个“合理终点”（geo_endpoint_x/y），
      让模型在此基础上学习偏差修正（residual learning），通常更稳、更好收敛。

    输入：
    - df: 输入特征表（通常是 input_df merge 完对手/镜像等特征后的版本）
      必须包含 x, y, velocity_x, velocity_y
      可选包含 num_frames_output, ball_land_x, ball_land_y, player_role,
      mirror_offset_x/y, mirror_wr_dist 等。

    输出：
    - 返回 df 的拷贝，并新增：
      * time_to_endpoint      : 估计“球在空中阶段”的总时长（秒）
      * geo_endpoint_x/y      : 规则推断的终点坐标（绝对位置）
    """
    df = df.copy()  # 防止外部 DataFrame 被原地修改（良好习惯：避免副作用）

    # ------------------------------------------------------------------
    # Step 1) 估计“未来预测区间”的总时长 t_total（秒）
    # ------------------------------------------------------------------
    # 数据约定：tracking 为 10Hz（每秒 10 帧），因此帧数 / 10 = 秒数
    # - 训练集通常有 num_frames_output（该球员要预测多少未来帧）
    # - 测试或缺失时，用一个保守默认值 3.0 秒兜底
    if 'num_frames_output' in df.columns:
        t_total = df['num_frames_output'] / 10.0
    else:
        t_total = 3.0

    df['time_to_endpoint'] = t_total  # 保存下来，后续几何特征会用到 t

    # ------------------------------------------------------------------
    # Step 2) 默认规则：匀速外推（动量/惯性基线）
    # ------------------------------------------------------------------
    # 假设球员在未来 t_total 秒内“维持当前速度分量不变”：
    #   endpoint = current_position + velocity * t_total
    # 这是一个很强的物理先验：即使不考虑战术，也比“停在原地”更合理。
    df['geo_endpoint_x'] = df['x'] + df['velocity_x'] * t_total
    df['geo_endpoint_y'] = df['y'] + df['velocity_y'] * t_total

    # ------------------------------------------------------------------
    # Step 3) 角色驱动的规则修正（利用比赛语义）
    # ------------------------------------------------------------------
    # 如果提供了 ball_land_x/y（落点），我们可以引入更强的“战术先验”：
    # - 目标接球者（Targeted Receiver）最终应当向落点收敛
    # - 覆盖防守者（Defensive Coverage）通常会“跟人/跟路线”，
    #   这里用“镜像最近跑路线的进攻球员”来近似
    if 'ball_land_x' in df.columns:
        # 规则 3.1：目标接球者 -> 终点直接设为落点
        receiver_mask = df['player_role'] == 'Targeted Receiver'
        df.loc[receiver_mask, 'geo_endpoint_x'] = df.loc[receiver_mask, 'ball_land_x']
        df.loc[receiver_mask, 'geo_endpoint_y'] = df.loc[receiver_mask, 'ball_land_y']

        # 规则 3.2：覆盖者镜像接球者（或最近跑路线者）
        # 思想：防守覆盖者的“目标”往往不是球，而是“要盯的人”；
        # 若我们能在传球前最后一帧估计“覆盖者相对接球者的偏移量”，
        # 那么球在空中时，覆盖者可能保持相似偏移，一起向落点附近移动。
        defender_mask = df['player_role'] == 'Defensive Coverage'

        # has_mirror 的含义：
        # - mirror_offset_x/y 不为空：说明我们成功找到了一个“镜像对象”
        # - mirror_wr_dist < 15：只在覆盖者与该对象足够近时才相信镜像关系
        #   （距离太远，镜像可能只是噪声匹配，宁可不用）
        has_mirror = df.get('mirror_offset_x', 0).notna() & (df.get('mirror_wr_dist', 50) < 15)
        coverage_mask = defender_mask & has_mirror

        # 覆盖者终点 = 落点 +（覆盖者相对镜像接球者的偏移）
        # 直觉：接球者冲向落点，覆盖者跟随接球者并维持相对位置
        df.loc[coverage_mask, 'geo_endpoint_x'] = (
            df.loc[coverage_mask, 'ball_land_x'] +
            df.loc[coverage_mask, 'mirror_offset_x'].fillna(0)
        )
        df.loc[coverage_mask, 'geo_endpoint_y'] = (
            df.loc[coverage_mask, 'ball_land_y'] +
            df.loc[coverage_mask, 'mirror_offset_y'].fillna(0)
        )

    # ------------------------------------------------------------------
    # Step 4) 场地边界裁剪（保证几何终点合法）
    # ------------------------------------------------------------------
    # 规则外推可能导致越界（例如匀速外推冲出边线、或落点附近偏移越界）
    # 这里强制把终点限制到球场坐标范围内，避免产生不合理目标。
    df['geo_endpoint_x'] = df['geo_endpoint_x'].clip(0.0, 120.0)
    df['geo_endpoint_y'] = df['geo_endpoint_y'].clip(0.0, 53.3)

    return df  # 返回带“几何终点 + 时间估计”的特征表

def add_geometric_features(df):
    """
    目标：在 compute_geometric_endpoint() 给出的“规则终点”基础上，
         生成一组更易学习、更可解释的几何派生特征（geo_*）。

    核心思想（教学版）：
    - compute_geometric_endpoint 只回答一个问题：『你觉得他最后大概率到哪？』
      => geo_endpoint_x/y
    - add_geometric_features 进一步回答：『为了到那儿，他现在该怎么动？差多少？是否对齐？』
      => 位移向量、距离、所需速度/加速度、对齐度、紧迫度、耦合强度等

    返回：
    - df（拷贝）+ 一系列 geo_* 特征，用于作为模型输入
    """
    # 先计算/补齐几何终点与 time_to_endpoint（上游规则基线）
    df = compute_geometric_endpoint(df)

    # ------------------------------------------------------------------
    # 1) 指向终点的位移向量 Δp = p_end - p_now
    # ------------------------------------------------------------------
    # geo_vector_* 表示“从当前位置指向规则终点”的方向与大小
    df['geo_vector_x'] = df['geo_endpoint_x'] - df['x']
    df['geo_vector_y'] = df['geo_endpoint_y'] - df['y']

    # 终点距离（欧氏距离）：||Δp||
    df['geo_distance'] = np.sqrt(df['geo_vector_x']**2 + df['geo_vector_y']**2)

    # ------------------------------------------------------------------
    # 2) 平均所需速度 v_req = Δp / t
    # ------------------------------------------------------------------
    # 为避免 t=0 或极小导致数值爆炸，加一个 0.1 秒缓冲（相当于数值稳定项）
    t = df['time_to_endpoint'] + 0.1
    df['geo_required_vx'] = df['geo_vector_x'] / t
    df['geo_required_vy'] = df['geo_vector_y'] / t

    # ------------------------------------------------------------------
    # 3) 速度误差：当前速度与“到达终点所需速度”的差
    # ------------------------------------------------------------------
    # 直观解释：
    # - 如果 required_v 与当前 velocity 很接近 => 按当前趋势走就能到终点（更“顺势”）
    # - 如果差很大 => 需要明显调整速度方向或大小（更“困难/不自然”）
    df['geo_velocity_error_x'] = df['geo_required_vx'] - df['velocity_x']
    df['geo_velocity_error_y'] = df['geo_required_vy'] - df['velocity_y']
    df['geo_velocity_error'] = np.sqrt(
        df['geo_velocity_error_x']**2 + df['geo_velocity_error_y']**2
    )

    # ------------------------------------------------------------------
    # 4) 匀加速到达所需加速度：a = 2*Δx / t^2（分量形式）
    # ------------------------------------------------------------------
    # 这是经典的位移公式：Δx = 0.5 * a * t^2 （假设初速度忽略/作为近似）
    # 这里更像一个“强度指标”：要达到几何终点，大概需要多猛的加速度修正
    t_sq = t * t
    df['geo_required_ax'] = 2 * df['geo_vector_x'] / t_sq
    df['geo_required_ay'] = 2 * df['geo_vector_y'] / t_sq

    # 数值与物理合理性裁剪：
    # 过大的加速度往往来自噪声/极小 t/异常数据，会扰乱训练
    df['geo_required_ax'] = df['geo_required_ax'].clip(-10, 10)
    df['geo_required_ay'] = df['geo_required_ay'].clip(-10, 10)

    # ------------------------------------------------------------------
    # 5) 当前速度与“去终点方向”的对齐度（cos 相似度）
    # ------------------------------------------------------------------
    # 计算：cos(theta) = (v · u) / (||v||)
    # - u 是指向终点的单位向量
    # - 若 geo_alignment 接近 1：正朝终点跑（对齐）
    # - 接近 0：跑向与终点垂直方向
    # - 接近 -1：背离终点
    velocity_mag = np.sqrt(df['velocity_x']**2 + df['velocity_y']**2)
    geo_unit_x = df['geo_vector_x'] / (df['geo_distance'] + 0.1)
    geo_unit_y = df['geo_vector_y'] / (df['geo_distance'] + 0.1)
    df['geo_alignment'] = (
        df['velocity_x'] * geo_unit_x + df['velocity_y'] * geo_unit_y
    ) / (velocity_mag + 0.1)

    # ------------------------------------------------------------------
    # 6) 角色相关的“提示性”几何特征（让模型更快学到战术差异）
    # ------------------------------------------------------------------
    # (a) 接球者紧迫度：距离越远、时间越短 => 越紧迫
    # 这里用 is_receiver * (distance / time) 来做一个简单指标
    df['geo_receiver_urgency'] = df['is_receiver'] * df['geo_distance'] / (t + 0.1)

    # (b) 覆盖者耦合强度：镜像对象越近（mirror_wr_dist 越小）=> 越可信/耦合越强
    # 1/(dist+1) 让距离小的时候值大，距离大时迅速衰减
    df['geo_defender_coupling'] = df['is_coverage'] * (1.0 / (df.get('mirror_wr_dist', 50) + 1.0))

    return df  # 返回新增 geo_* 特征后的表

def get_velocity(speed, direction_deg):
    theta = np.deg2rad(direction_deg)  # 将角度制方向转为弧度
    return speed * np.sin(theta), speed * np.cos(theta)  # 分解到场地坐标系 (vx, vy)

def height_to_feet(height_str):
    try:
        ft, inches = map(int, str(height_str).split('-'))  # 将 "6-2" 解析为 (6,2)
        return ft + inches/12  # 英尺 = ft + inches/12
    except:
        return 6.0  # 缺失/异常时给默认身高

def get_opponent_features(input_df):
    """
    目标：为每个球员（game_id, play_id, nfl_id）构造“对手交互”特征。
    ----------------------------------------------------------------------
    为什么需要“对手交互”？
    - 仅看自己的速度/方向/位置，很难判断“我是否正被逼抢、是否在盯人、周围是否拥挤”。
    - 橄榄球是强对抗/强交互运动：附近对手位置与相对运动，会显著影响未来轨迹。

    本函数输出的特征可以分为 3 组：

    (A) 最近对手距离与拥挤度
        - nearest_opp_dist      : 最近对手距离（码）
        - num_nearby_opp_3/5    : 3码/5码内对手数量（密集程度）

    (B) 与最近对手的“接近速度”
        - closing_speed         : 两者相对速度在“对手->我”方向上的投影（>0 表示正在靠近）

    (C) “镜像接球者”（只对 Defensive Coverage）
        - mirror_wr_* 与 mirror_offset_*:
          用最近的跑路线进攻方（Targeted Receiver / Other Route Runner）当作“我在盯的那个人”的近似。
          这会给后续几何规则/模型提供一个很强的先验：覆盖者往往“跟人”而不只是“追球”。

    注意：
    - 我们只在“传球前最后一帧”上计算这些交互特征（极大降低计算量，并贴近出手瞬间的战术状态）。
    - 然后把这些按球员聚合的一行特征 merge 回每一帧输入序列（让模型在所有历史帧都能看到这份“末帧交互摘要”）。
    """
    features = []  # 收集每个 (game_id, play_id, nfl_id) 的汇总特征
    
    # ======================================================================
    # Step 0) 以 (game_id, play_id) 为单位处理：每个回合单独算一次“末帧交互”
    # ======================================================================
    # 原因：对手关系只在同一 play 内有意义；不同 play 不能混在一起算距离。
    for (gid, pid), group in tqdm(input_df.groupby(['game_id', 'play_id']), 
                                   desc="🏈 Opponents", leave=False):
        # --------------------------------------------------------------
        # Step 1) 取“传球前最后一帧”的状态：每名球员只保留 1 行（末帧）
        # --------------------------------------------------------------
        # last 的索引是 nfl_id；列里有该球员末帧的 x/y/s/dir/role/side 等。
        last = group.sort_values('frame_id').groupby('nfl_id').last()
        
        # 球员过少无法构建“对手”概念，直接跳过
        if len(last) < 2:
            continue
            
        # --------------------------------------------------------------
        # Step 2) 准备向量化计算所需数组（位置/阵营/速度/方向/角色）
        # --------------------------------------------------------------
        positions = last[['x', 'y']].values
        sides = last['player_side'].values
        speeds = last['s'].values
        directions = last['dir'].values
        roles = last['player_role'].values
        
        # receiver_mask：所有可能“跑路线”的进攻方（用于覆盖者的“镜像对象”查找）
        receiver_mask = np.isin(roles, ['Targeted Receiver', 'Other Route Runner'])
        
        # ==================================================================
        # Step 3) 遍历该 play 的每名球员 i：计算“与对手的空间/速度关系”
        # ==================================================================
        for i, (nid, side, role) in enumerate(zip(last.index, sides, roles)):
            opp_mask = sides != side  # 对手：阵营相反
            
            # -------------------------------
            # Step 3.0) 初始化默认值（鲁棒兜底）
            # -------------------------------
            # 这样即使后面因为缺对手/缺接球者等原因跳过，仍能输出一行完整特征。
            feat = {
                'game_id': gid, 'play_id': pid, 'nfl_id': nid,
                'nearest_opp_dist': 50.0, 'closing_speed': 0.0,
                'num_nearby_opp_3': 0, 'num_nearby_opp_5': 0,
                'mirror_wr_vx': 0.0, 'mirror_wr_vy': 0.0,
                'mirror_offset_x': 0.0, 'mirror_offset_y': 0.0,
                'mirror_wr_dist': 50.0,
            }
            
            # 没有对手（极少见/异常），直接写默认值
            if not opp_mask.any():
                features.append(feat)
                continue
            
            # -------------------------------
            # Step 3.1) 空间：找最近对手 + 拥挤度统计
            # -------------------------------
            opp_positions = positions[opp_mask]
            distances = np.sqrt(((positions[i] - opp_positions)**2).sum(axis=1))
            
            if len(distances) == 0:
                features.append(feat)
                continue
                
            nearest_idx = distances.argmin()
            feat['nearest_opp_dist'] = distances[nearest_idx]
            feat['num_nearby_opp_3'] = (distances < 3.0).sum()
            feat['num_nearby_opp_5'] = (distances < 5.0).sum()
            
            # -------------------------------
            # Step 3.2) 速度：计算“接近速度 closing_speed”
            # -------------------------------
            # 核心：把相对速度 (v_me - v_opp) 投影到“对手->我”的方向上。
            # - 若投影为负：表示我在远离对手（或对手在远离我）
            # - 我们再取负号，使得“正在靠近”时 closing_speed > 0，更直观
            my_vx, my_vy = get_velocity(speeds[i], directions[i])
            opp_speeds = speeds[opp_mask]
            opp_dirs = directions[opp_mask]
            opp_vx, opp_vy = get_velocity(opp_speeds[nearest_idx], opp_dirs[nearest_idx])
            
            rel_vx = my_vx - opp_vx
            rel_vy = my_vy - opp_vy
            to_me = positions[i] - opp_positions[nearest_idx]
            to_me_norm = to_me / (np.linalg.norm(to_me) + 0.1)
            feat['closing_speed'] = -(rel_vx * to_me_norm[0] + rel_vy * to_me_norm[1])
            
            # -------------------------------
            # Step 3.3) 覆盖者专属：找“镜像接球者/跑路线者”
            # -------------------------------
            # 直觉：Defensive Coverage 未来走位往往“跟人”：
            # - 找最近的可能跑路线进攻球员当作“我盯的人”
            # - 记录对方速度分量、以及我相对对方的空间偏移（offset）
            if role == 'Defensive Coverage' and receiver_mask.any():
                rec_positions = positions[receiver_mask]
                rec_distances = np.sqrt(((positions[i] - rec_positions)**2).sum(axis=1))
                
                if len(rec_distances) > 0:
                    closest_rec_idx = rec_distances.argmin()
                    rec_indices = np.where(receiver_mask)[0]
                    actual_rec_idx = rec_indices[closest_rec_idx]
                    
                    rec_vx, rec_vy = get_velocity(speeds[actual_rec_idx], directions[actual_rec_idx])
                    
                    feat['mirror_wr_vx'] = rec_vx
                    feat['mirror_wr_vy'] = rec_vy
                    feat['mirror_wr_dist'] = rec_distances[closest_rec_idx]
                    feat['mirror_offset_x'] = positions[i][0] - rec_positions[closest_rec_idx][0]
                    feat['mirror_offset_y'] = positions[i][1] - rec_positions[closest_rec_idx][1]
            
            # 写入该球员的特征行
            features.append(feat)
    
    # 输出：每名球员一行（按 play 聚合），后面会 merge 回 input_df
    return pd.DataFrame(features)

def extract_route_patterns(input_df, kmeans=None, scaler=None, fit=True):
    """
    对每个 (game, play, player) 取 最后 5 帧 的轨迹片段，构造“跑路线形状”的统计特征，然后 StandardScaler + KMeans(n_clusters=7) 得到离散标签 route_pattern。
    """
    route_features = []
    
    # ======================================================================
    # Step 0) 以 (game, play, player) 为单位：提取末尾 5 帧轨迹片段
    # ======================================================================
    for (gid, pid, nid), group in tqdm(input_df.groupby(['game_id', 'play_id', 'nfl_id']), 
                                        desc="🛣️  Routes", leave=False):
        # 取最靠近出手的 5 帧（窗口末端最能反映“出手瞬间”跑位趋势）
        traj = group.sort_values('frame_id').tail(5)
        
        # 帧太少时，角度变化等统计不稳定，跳过
        if len(traj) < 3:
            continue
        
        positions = traj[['x', 'y']].values
        speeds = traj['s'].values
        
        # ==================================================================
        # Step 1) 直线性：位移 / 路程
        # ==================================================================
        # total_dist：沿着轨迹走过的总路程（每一步距离之和）
        total_dist = np.sum(np.sqrt(np.diff(positions[:, 0])**2 + np.diff(positions[:, 1])**2))
        # displacement：首尾直线距离（“净位移”）
        displacement = np.sqrt((positions[-1, 0] - positions[0, 0])**2 + 
                              (positions[-1, 1] - positions[0, 1])**2)
        # straightness 越接近 1 越直；加 0.1 防止 total_dist=0
        straightness = displacement / (total_dist + 0.1)
        
        # ==================================================================
        # Step 2) 转向幅度：基于相邻位移向量的方向角变化
        # ==================================================================
        angles = np.arctan2(np.diff(positions[:, 1]), np.diff(positions[:, 0]))
        if len(angles) > 1:
            angle_changes = np.abs(np.diff(angles))
            max_turn = np.max(angle_changes)
            mean_turn = np.mean(angle_changes)
        else:
            max_turn = mean_turn = 0
        
        # ==================================================================
        # Step 3) 深度/宽度 + 速度统计
        # ==================================================================
        speed_mean = speeds.mean()
        speed_change = speeds[-1] - speeds[0] if len(speeds) > 1 else 0
        dx = positions[-1, 0] - positions[0, 0]
        dy = positions[-1, 1] - positions[0, 1]
        
        route_features.append({
            'game_id': gid, 'play_id': pid, 'nfl_id': nid,
            'traj_straightness': straightness,
            'traj_max_turn': max_turn,
            'traj_mean_turn': mean_turn,
            'traj_depth': abs(dx),
            'traj_width': abs(dy),
            'speed_mean': speed_mean,
            'speed_change': speed_change,
        })
    
    # ======================================================================
    # Step 4) 聚类：标准化 -> KMeans -> route_pattern
    # ======================================================================
    route_df = pd.DataFrame(route_features)
    feat_cols = ['traj_straightness', 'traj_max_turn', 'traj_mean_turn',
                 'traj_depth', 'traj_width', 'speed_mean', 'speed_change']
    X = route_df[feat_cols].fillna(0)
    
    if fit:
        # 训练阶段：拟合 scaler 和 kmeans（route_pattern 的定义在训练时固定下来）
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        kmeans = KMeans(n_clusters=7, random_state=42, n_init=10)
        route_df['route_pattern'] = kmeans.fit_predict(X_scaled)
        return route_df, kmeans, scaler
    else:
        # 推理阶段：复用训练的 scaler/kmeans，避免“簇编号含义漂移”
        X_scaled = scaler.transform(X)
        route_df['route_pattern'] = kmeans.predict(X_scaled)
        return route_df

def compute_neighbor_embeddings(input_df, k_neigh=6, radius=30.0, tau=8.0):
    """
    目标：在“传球前最后一帧”上构建一个轻量的邻域聚合（GNN-lite）表示。
    ----------------------------------------------------------------------
    为什么要做“邻域聚合”？
    - 球员的未来运动强依赖周围人的相对位置/相对速度（比如：有人贴身、有人拉开、队友形成掩护）。
    - 直接把“所有其他球员”作为输入维度会爆炸且顺序不固定。
    - 因此用一种“可微/可压缩”的方式，把邻居信息汇总成固定长度向量：
        (友军通道聚合) + (对手通道聚合) + (邻居数量/距离统计)

    关键设计：
    1) 只在末帧构图（last frame），大幅降低计算量
    2) 只取半径 radius 内的邻居，并最多取 k_neigh 个最近邻
    3) 距离衰减权重 w=exp(-dist/tau)，越近权重越大
    4) 友军/对手分通道聚合（让模型区分“队友结构”与“防守压力”）

    输出（每个球员一行）大致包含：
    - gnn_ally_dx_mean / gnn_opp_dx_mean ... : 邻居相对位移/相对速度差的加权均值
    - gnn_ally_cnt / gnn_opp_cnt            : 邻居数量（友军/对手）
    - gnn_ally_dmin/dmean, gnn_opp_dmin/dmean: 友军/对手距离统计
    - gnn_d1/d2/d3                          : 最近 1/2/3 个邻居距离（不分阵营）
    """
    print("🕸️  GNN embeddings...")
    
    # ======================================================================
    # Step 0) 只保留必要列：减少 merge/内存压力
    # ======================================================================
    cols_needed = ["game_id", "play_id", "nfl_id", "frame_id", "x", "y", 
                   "velocity_x", "velocity_y", "player_side"]
    src = input_df[cols_needed].copy()
    
    # ======================================================================
    # Step 1) 找每个球员在传球前的“最后一帧”（每人一个节点）
    # ======================================================================
    last = (src.sort_values(["game_id", "play_id", "nfl_id", "frame_id"])
               .groupby(["game_id", "play_id", "nfl_id"], as_index=False)
               .tail(1)
               .rename(columns={"frame_id": "last_frame_id"})
               .reset_index(drop=True))
    
    # ======================================================================
    # Step 2) 构建候选邻边：把“中心节点 last”与“同一帧的所有球员 src”做匹配
    # ======================================================================
    # 这样得到 tmp：每行是 (中心球员, 邻居球员) 的一条候选边（同一 play 同一帧）
    tmp = last.merge(
        src.rename(columns={
            "frame_id": "nb_frame_id", "nfl_id": "nfl_id_nb",
            "x": "x_nb", "y": "y_nb", 
            "velocity_x": "vx_nb", "velocity_y": "vy_nb", 
            "player_side": "player_side_nb"
        }),
        left_on=["game_id", "play_id", "last_frame_id"],
        right_on=["game_id", "play_id", "nb_frame_id"],
        how="left"
    )
    
    # 去掉自环：自己不当自己的邻居
    tmp = tmp[tmp["nfl_id_nb"] != tmp["nfl_id"]]
    
    # ======================================================================
    # Step 3) 边特征：相对位移/相对速度差/距离
    # ======================================================================
    tmp["dx"] = tmp["x_nb"] - tmp["x"]
    tmp["dy"] = tmp["y_nb"] - tmp["y"]
    tmp["dvx"] = tmp["vx_nb"] - tmp["velocity_x"]
    tmp["dvy"] = tmp["vy_nb"] - tmp["velocity_y"]
    tmp["dist"] = np.sqrt(tmp["dx"]**2 + tmp["dy"]**2)
    
    # 清理非法/零距离（数值稳定 + 避免权重异常）
    tmp = tmp[np.isfinite(tmp["dist"]) & (tmp["dist"] > 1e-6)]
    if radius is not None:
        tmp = tmp[tmp["dist"] <= radius]
    
    # ======================================================================
    # Step 4) 友军/对手标记 + 最近邻筛选（最多 k_neigh 个）
    # ======================================================================
    tmp["is_ally"] = (tmp["player_side_nb"] == tmp["player_side"]).astype(np.float32)
    
    keys = ["game_id", "play_id", "nfl_id"]
    tmp["rnk"] = tmp.groupby(keys)["dist"].rank(method="first")
    if k_neigh is not None:
        tmp = tmp[tmp["rnk"] <= float(k_neigh)]
    
    # ======================================================================
    # Step 5) 距离衰减权重 + 归一化
    # ======================================================================
    # w 越近越大；wn 在每个中心节点内部归一（加权平均）
    tmp["w"] = np.exp(-tmp["dist"] / float(tau))
    sum_w = tmp.groupby(keys)["w"].transform("sum")
    tmp["wn"] = np.where(sum_w > 0, tmp["w"] / sum_w, 0.0)
    
    # 友军/对手分通道权重：同一个 wn 再按阵营切分
    tmp["wn_ally"] = tmp["wn"] * tmp["is_ally"]
    tmp["wn_opp"] = tmp["wn"] * (1.0 - tmp["is_ally"])
    
    # ======================================================================
    # Step 6) 用“加权相对量”做聚合：得到固定维度的邻域嵌入
    # ======================================================================
    for col in ["dx", "dy", "dvx", "dvy"]:
        tmp[f"{col}_ally_w"] = tmp[col] * tmp["wn_ally"]
        tmp[f"{col}_opp_w"] = tmp[col] * tmp["wn_opp"]
    
    # 为友军/对手距离统计准备列（非该类置 NaN，方便 min/mean 聚合）
    tmp["dist_ally"] = np.where(tmp["is_ally"] > 0.5, tmp["dist"], np.nan)
    tmp["dist_opp"] = np.where(tmp["is_ally"] < 0.5, tmp["dist"], np.nan)
    
    # 按中心节点聚合：sum(加权相对量) 等价于加权均值（因为 wn 已归一）
    ag = tmp.groupby(keys).agg(
        gnn_ally_dx_mean=("dx_ally_w", "sum"),
        gnn_ally_dy_mean=("dy_ally_w", "sum"),
        gnn_ally_dvx_mean=("dvx_ally_w", "sum"),
        gnn_ally_dvy_mean=("dvy_ally_w", "sum"),
        gnn_opp_dx_mean=("dx_opp_w", "sum"),
        gnn_opp_dy_mean=("dy_opp_w", "sum"),
        gnn_opp_dvx_mean=("dvx_opp_w", "sum"),
        gnn_opp_dvy_mean=("dvy_opp_w", "sum"),
        gnn_ally_cnt=("is_ally", "sum"),
        gnn_opp_cnt=("is_ally", lambda s: float(len(s) - s.sum())),
        gnn_ally_dmin=("dist_ally", "min"),
        gnn_ally_dmean=("dist_ally", "mean"),
        gnn_opp_dmin=("dist_opp", "min"),
        gnn_opp_dmean=("dist_opp", "mean"),
    ).reset_index()
    
    # ======================================================================
    # Step 7) 额外输出最近 1/2/3 邻居距离（更细粒度的“贴身程度”信号）
    # ======================================================================
    near = tmp.loc[tmp["rnk"] <= 3, keys + ["rnk", "dist"]].copy()
    if len(near) > 0:
        near["rnk"] = near["rnk"].astype(int)
        dwide = near.pivot_table(index=keys, columns="rnk", values="dist", aggfunc="first")
        dwide = dwide.rename(columns={1: "gnn_d1", 2: "gnn_d2", 3: "gnn_d3"}).reset_index()
        ag = ag.merge(dwide, on=keys, how="left")
    
    # ======================================================================
    # Step 8) 缺失填充（某些球员可能没有邻居/被半径截断掉）
    # ======================================================================
    # - 向量类缺失 => 0（表示“邻域相对信息不可用/空”）
    # - 距离类缺失 => radius（表示“最近邻至少在半径外”）
    for c in ["gnn_ally_dx_mean", "gnn_ally_dy_mean", "gnn_ally_dvx_mean", "gnn_ally_dvy_mean",
              "gnn_opp_dx_mean", "gnn_opp_dy_mean", "gnn_opp_dvx_mean", "gnn_opp_dvy_mean"]:
        ag[c] = ag[c].fillna(0.0)
    for c in ["gnn_ally_cnt", "gnn_opp_cnt"]:
        ag[c] = ag[c].fillna(0.0)
    for c in ["gnn_ally_dmin", "gnn_opp_dmin", "gnn_ally_dmean", "gnn_opp_dmean", 
              "gnn_d1", "gnn_d2", "gnn_d3"]:
        ag[c] = ag[c].fillna(radius if radius is not None else 30.0)
    
    return ag



# ============================================================================
# 序列构造（融合几何特征）
# ============================================================================

def prepare_sequences_geometric(input_df, output_df=None, test_template=None, 
                                is_training=True, window_size=10,
                                route_kmeans=None, route_scaler=None):
    """
    构造序列样本（用于 GRU/Transformer 等序列模型）：
    - 输入：传球前追踪序列（最近 window_size 帧）
    - 输出（训练）：未来每帧相对位移序列 (dx, dy)
    - 输出（推理）：仅输入序列与对应的 (game_id, play_id, nfl_id) 标识

    设计理念（非常重要）：
    1) 我们把“传球前最后 window_size 帧”当作历史上下文，让模型预测“球在空中阶段”的运动轨迹。
    2) 特征分 5 大块：
       A. 基础追踪/身体/阵营/角色特征（让模型知道“人是谁、在哪、朝哪、动得怎样”）
       B. 与落点 ball_land_x/y 的几何关系（让模型知道“球落哪、我离哪、我是否正朝那里去”）
       C. 对手/镜像接球者/路线聚类/邻域聚合（让模型知道“人与人之间的关系结构”）
       D. 时间序列派生（lag/rolling/delta/ema，让模型更容易学短期动力学）
       E. 几何基线终点特征（geo_*：先用规则给“合理终点”，模型只学习偏差修正）
    3) 训练目标采用“相对位移序列”而非绝对坐标：
       target_dx[t] = x_future[t] - x_last_input
       target_dy[t] = y_future[t] - y_last_input
       这样模型更容易学习“增量/变化”，也便于累加得到轨迹。

    参数说明：
    - input_df: 传球前追踪数据（train input 或 test_input）
    - output_df: 训练输出（train output），包含传球后每帧 x/y 真值（训练时必需）
    - test_template: 测试模板（test.csv），定义了要预测哪些 (game,play,player,frame)
    - is_training: True=训练数据管线；False=推理管线
    - window_size: 使用多少帧历史作为模型输入
    - route_kmeans/route_scaler: 推理时复用训练得到的路线聚类器，保证簇含义一致

    返回：
    - 训练：sequences, targets_dx, targets_dy, targets_frame_ids, sequence_ids,
            geo_endpoints_x, geo_endpoints_y, route_kmeans, route_scaler
    - 推理：sequences, sequence_ids, geo_endpoints_x, geo_endpoints_y
    """

    print(f"\n{'='*80}")
    print(f"PREPARING GEOMETRIC SEQUENCES")
    print(f"{'='*80}")

    # ----------------------------------------------------------------------
    # 0) 基础准备：排序保证时序一致
    # ----------------------------------------------------------------------
    input_df = input_df.copy()
    input_df = input_df.sort_values(['game_id', 'play_id', 'nfl_id', 'frame_id'])

    print("Step 1: Base features...")

    # ----------------------------------------------------------------------
    # 1) 身体/体型特征（body）
    # ----------------------------------------------------------------------
    # player_height_feet: 把 "6-2" -> 6.166...（英尺）
    input_df['player_height_feet'] = input_df['player_height'].apply(height_to_feet)

    # height_inches: 身高（英寸），例如 6-2 -> 74
    # bmi: 用英制 BMI 公式（703 系数）
    height_parts = input_df['player_height'].str.split('-', expand=True)
    input_df['height_inches'] = height_parts[0].astype(float) * 12 + height_parts[1].astype(float)
    input_df['bmi'] = (input_df['player_weight'] / (input_df['height_inches']**2)) * 703

    # ----------------------------------------------------------------------
    # 2) 速度/加速度分解（kinematics）
    # ----------------------------------------------------------------------
    # 注意：这里使用 dir 作为“运动方向”（而 o 更像身体朝向）
    dir_rad = np.deg2rad(input_df['dir'].fillna(0))

    # velocity_x / velocity_y: 把速度标量 s 按 dir 分解到 (x,y)
    input_df['velocity_x'] = input_df['s'] * np.sin(dir_rad)
    input_df['velocity_y'] = input_df['s'] * np.cos(dir_rad)

    # acceleration_x / acceleration_y: 把加速度标量 a 按 dir 分解到 (x,y)
    input_df['acceleration_x'] = input_df['a'] * np.cos(dir_rad)
    input_df['acceleration_y'] = input_df['a'] * np.sin(dir_rad)

    # ----------------------------------------------------------------------
    # 3) 动力学派生（physics-inspired）
    # ----------------------------------------------------------------------
    # speed_squared: s^2（速度平方，常用于能量/强度表征）
    input_df['speed_squared'] = input_df['s'] ** 2

    # accel_magnitude: 加速度向量模长 ||a||
    input_df['accel_magnitude'] = np.sqrt(input_df['acceleration_x']**2 + input_df['acceleration_y']**2)

    # momentum_x/y: 动量分量（用体重当“质量”代理）
    input_df['momentum_x'] = input_df['velocity_x'] * input_df['player_weight']
    input_df['momentum_y'] = input_df['velocity_y'] * input_df['player_weight']

    # kinetic_energy: 动能（同样用体重当质量代理）
    input_df['kinetic_energy'] = 0.5 * input_df['player_weight'] * input_df['speed_squared']

    # orientation_diff: 身体朝向 o 与运动方向 dir 的最小环形角差（0~180）
    input_df['orientation_diff'] = np.abs(input_df['o'] - input_df['dir'])
    input_df['orientation_diff'] = np.minimum(input_df['orientation_diff'], 360 - input_df['orientation_diff'])

    # ----------------------------------------------------------------------
    # 4) 阵营/角色 one-hot（identity）
    # ----------------------------------------------------------------------
    # is_offense / is_defense: 阵营
    # is_receiver / is_coverage / is_passer: 关键角色
    input_df['is_offense'] = (input_df['player_side'] == 'Offense').astype(int)
    input_df['is_defense'] = (input_df['player_side'] == 'Defense').astype(int)
    input_df['is_receiver'] = (input_df['player_role'] == 'Targeted Receiver').astype(int)
    input_df['is_coverage'] = (input_df['player_role'] == 'Defensive Coverage').astype(int)
    input_df['is_passer'] = (input_df['player_role'] == 'Passer').astype(int)

    # 下面这些是“冗余/显式命名”的 one-hot（让特征名更语义化）
    input_df['role_targeted_receiver'] = input_df['is_receiver']
    input_df['role_defensive_coverage'] = input_df['is_coverage']
    input_df['role_passer'] = input_df['is_passer']
    input_df['side_offense'] = input_df['is_offense']

    # ----------------------------------------------------------------------
    # 5) 与落点相关特征（ball landing geometry）
    # ----------------------------------------------------------------------
    # 这部分只在提供 ball_land_x/y 时计算（训练与正式测试通常都有）
    if 'ball_land_x' in input_df.columns:
        # ball_dx/dy: 从球员当前位置指向落点的向量
        ball_dx = input_df['ball_land_x'] - input_df['x']
        ball_dy = input_df['ball_land_y'] - input_df['y']

        # distance_to_ball / dist_to_ball: 到落点距离（两列同义，保留是因为历史特征沿用）
        input_df['distance_to_ball'] = np.sqrt(ball_dx**2 + ball_dy**2)
        input_df['dist_to_ball'] = input_df['distance_to_ball']

        # dist_squared: 距离平方（有时比距离更线性）
        input_df['dist_squared'] = input_df['distance_to_ball'] ** 2

        # angle_to_ball: 指向落点的方向角（弧度）
        input_df['angle_to_ball'] = np.arctan2(ball_dy, ball_dx)

        # ball_direction_x/y: 指向落点的单位方向向量
        input_df['ball_direction_x'] = ball_dx / (input_df['distance_to_ball'] + 1e-6)
        input_df['ball_direction_y'] = ball_dy / (input_df['distance_to_ball'] + 1e-6)

        # closing_speed_ball: 当前速度在“指向落点方向”的投影（>0 表示正在接近落点）
        input_df['closing_speed_ball'] = (
            input_df['velocity_x'] * input_df['ball_direction_x'] +
            input_df['velocity_y'] * input_df['ball_direction_y']
        )

        # velocity_toward_ball: 与 closing_speed_ball 语义相近（另一种投影写法）
        input_df['velocity_toward_ball'] = (
            input_df['velocity_x'] * np.cos(input_df['angle_to_ball']) +
            input_df['velocity_y'] * np.sin(input_df['angle_to_ball'])
        )

        # velocity_alignment: 运动方向 dir 与指向落点方向的夹角余弦（1=同向，-1=反向）
        input_df['velocity_alignment'] = np.cos(input_df['angle_to_ball'] - dir_rad)

        # angle_diff: 身体朝向 o 与指向落点方向（度）的最小环形角差（0~180）
        input_df['angle_diff'] = np.abs(input_df['o'] - np.degrees(input_df['angle_to_ball']))
        input_df['angle_diff'] = np.minimum(input_df['angle_diff'], 360 - input_df['angle_diff'])

    print("Step 2: Advanced features...")

    # ----------------------------------------------------------------------
    # 6) 对手交互特征（opponent / mirror receiver）
    # ----------------------------------------------------------------------
    # 这里会在“传球前最后一帧”上，为每个球员聚合出一行特征：
    # - nearest_opp_dist: 最近对手距离
    # - closing_speed: 与最近对手的接近速度（>0 越靠近）
    # - num_nearby_opp_3/5: 3码/5码内对手数
    # - mirror_*: 只对 Defensive Coverage 生成，表示其“最近接球/跑路线者”的信息与相对偏移
    opp_features = get_opponent_features(input_df)
    input_df = input_df.merge(opp_features, on=['game_id', 'play_id', 'nfl_id'], how='left')

    # ----------------------------------------------------------------------
    # 7) 路线聚类（route pattern）
    # ----------------------------------------------------------------------
    # 用传球前最后若干帧的轨迹形状做 KMeans，把“跑法模式”离散化成 route_pattern
    if is_training:
        route_features, route_kmeans, route_scaler = extract_route_patterns(input_df)
    else:
        route_features = extract_route_patterns(input_df, route_kmeans, route_scaler, fit=False)
    input_df = input_df.merge(route_features, on=['game_id', 'play_id', 'nfl_id'], how='left')

    # ----------------------------------------------------------------------
    # 8) 邻域聚合嵌入（lightweight GNN embedding）
    # ----------------------------------------------------------------------
    # 在传球前最后一帧构图：同帧球员之间按距离找近邻，并区分友军/对手做加权聚合
    gnn_features = compute_neighbor_embeddings(input_df)
    input_df = input_df.merge(gnn_features, on=['game_id', 'play_id', 'nfl_id'], how='left')

    # ----------------------------------------------------------------------
    # 9) 压力与镜像相似性（pressure / mirroring）
    # ----------------------------------------------------------------------
    # pressure: 1 / 最近对手距离（越近压力越大）
    # under_pressure: 最近对手是否 < 3码
    # pressure_x_speed: 压力与速度交互（高速+近防守 = 更“危险”）
    if 'nearest_opp_dist' in input_df.columns:
        input_df['pressure'] = 1 / np.maximum(input_df['nearest_opp_dist'], 0.5)
        input_df['under_pressure'] = (input_df['nearest_opp_dist'] < 3).astype(int)
        input_df['pressure_x_speed'] = input_df['pressure'] * input_df['s']

    # mirror_similarity: 覆盖者速度与其镜像接球者速度的相似（内积/速度归一）
    # mirror_offset_dist: 覆盖者与镜像接球者的空间偏移距离
    # mirror_alignment: 把 mirror_similarity 只作用在覆盖者上（非覆盖者置 0）
    if 'mirror_wr_vx' in input_df.columns:
        s_safe = np.maximum(input_df['s'], 0.1)
        input_df['mirror_similarity'] = (
            input_df['velocity_x'] * input_df['mirror_wr_vx'] +
            input_df['velocity_y'] * input_df['mirror_wr_vy']
        ) / s_safe
        input_df['mirror_offset_dist'] = np.sqrt(
            input_df['mirror_offset_x']**2 + input_df['mirror_offset_y']**2
        )
        input_df['mirror_alignment'] = input_df['mirror_similarity'] * input_df['role_defensive_coverage']

    print("Step 3: Temporal features...")

    # ----------------------------------------------------------------------
    # 10) 时间序列派生（lag / rolling / delta / EMA）
    # ----------------------------------------------------------------------
    # 分组键：同一名球员在同一 play 内的时序
    gcols = ['game_id', 'play_id', 'nfl_id']

    # (a) 多阶滞后特征：x_lag1 表示上一帧的 x；velocity_x_lag3 表示 3 帧前速度分量
    # 目的：显式提供“短期历史”，减少模型自己从序列里抽取差分的难度
    for lag in [1, 2, 3, 4, 5]:
        for col in ['x', 'y', 'velocity_x', 'velocity_y', 's', 'a']:
            if col in input_df.columns:
                input_df[f'{col}_lag{lag}'] = input_df.groupby(gcols)[col].shift(lag)

    # (b) 滑动窗口统计：rolling_mean/std（窗口=3 或 5 帧）
    # 目的：刻画局部平稳性/抖动程度（std 大可能表示急停急转或追踪噪声）
    for window in [3, 5]:
        for col in ['x', 'y', 'velocity_x', 'velocity_y', 's']:
            if col in input_df.columns:
                input_df[f'{col}_rolling_mean_{window}'] = (
                    input_df.groupby(gcols)[col]
                            .rolling(window, min_periods=1).mean()
                            .reset_index(level=[0, 1, 2], drop=True)
                )
                input_df[f'{col}_rolling_std_{window}'] = (
                    input_df.groupby(gcols)[col]
                            .rolling(window, min_periods=1).std()
                            .reset_index(level=[0, 1, 2], drop=True)
                )

    # (c) 一阶差分：velocity_x_delta = v_x[t] - v_x[t-1]
    # 目的：提供“速度变化趋势”的近似（对噪声也更鲁棒）
    for col in ['velocity_x', 'velocity_y']:
        if col in input_df.columns:
            input_df[f'{col}_delta'] = input_df.groupby(gcols)[col].diff()

    # (d) 指数滑动平均 EMA：平滑速度/速度模，抑制追踪抖动
    input_df['velocity_x_ema'] = input_df.groupby(gcols)['velocity_x'].transform(
        lambda x: x.ewm(alpha=0.3, adjust=False).mean()
    )
    input_df['velocity_y_ema'] = input_df.groupby(gcols)['velocity_y'].transform(
        lambda x: x.ewm(alpha=0.3, adjust=False).mean()
    )
    input_df['speed_ema'] = input_df.groupby(gcols)['s'].transform(
        lambda x: x.ewm(alpha=0.3, adjust=False).mean()
    )

    print("Step 4: Time features...")

    # ----------------------------------------------------------------------
    # 11) 时间/进度特征（time / progress）
    # ----------------------------------------------------------------------
    # 这些特征依赖 num_frames_output
    if 'num_frames_output' in input_df.columns:
        max_frames = input_df['num_frames_output']

        # max_play_duration: 未来总时长（秒）= num_frames_output / 10
        input_df['max_play_duration'] = max_frames / 10.0

        # frame_time: 当前 frame 对应时间（秒）= frame_id / 10
        input_df['frame_time'] = input_df['frame_id'] / 10.0

        # progress_ratio: 当前帧在“未来长度”中的进度比例（0~1+）
        input_df['progress_ratio'] = input_df['frame_id'] / np.maximum(max_frames, 1)

        # time_remaining / frames_remaining: 距离“未来结束”还剩多少
        input_df['time_remaining'] = (max_frames - input_df['frame_id']) / 10.0
        input_df['frames_remaining'] = max_frames - input_df['frame_id']

        # expected_x_at_ball / expected_y_at_ball: 假设匀速，从当前位置外推到 frame_time 的期望位置
        # （一种“物理朴素预测”参照）
        input_df['expected_x_at_ball'] = input_df['x'] + input_df['velocity_x'] * input_df['frame_time']
        input_df['expected_y_at_ball'] = input_df['y'] + input_df['velocity_y'] * input_df['frame_time']

        # error_from_ball_*: 上述匀速外推与落点的误差（越大表示需要更强调整/转向/加速）
        if 'ball_land_x' in input_df.columns:
            input_df['error_from_ball_x'] = input_df['expected_x_at_ball'] - input_df['ball_land_x']
            input_df['error_from_ball_y'] = input_df['expected_y_at_ball'] - input_df['ball_land_y']
            input_df['error_from_ball'] = np.sqrt(
                input_df['error_from_ball_x']**2 + input_df['error_from_ball_y']**2
            )

            # weighted_dist_by_time: 距离按时间惩罚（越早离得远越“贵”）
            input_df['weighted_dist_by_time'] = input_df['dist_to_ball'] / (input_df['frame_time'] + 0.1)

            # dist_scaled_by_progress: 用 (1-progress) 缩放距离，让“早期距离”更突出
            input_df['dist_scaled_by_progress'] = input_df['dist_to_ball'] * (1 - input_df['progress_ratio'])

        # time_squared: 时间的二次项（给模型一个非线性时间基）
        input_df['time_squared'] = input_df['frame_time'] ** 2

        # velocity_*_progress: 速度与进度的交互项（同样提供非线性）
        input_df['velocity_x_progress'] = input_df['velocity_x'] * input_df['progress_ratio']
        input_df['velocity_y_progress'] = input_df['velocity_y'] * input_df['progress_ratio']

        # speed_scaled_by_time_left: 速度×剩余时间（粗略表示“还能跑多远”）
        input_df['speed_scaled_by_time_left'] = input_df['s'] * input_df['time_remaining']

        # actual_play_length: 未来长度（帧）本体
        input_df['actual_play_length'] = max_frames

        # length_ratio: 相对 3 秒(30 帧)的长度比例
        input_df['length_ratio'] = max_frames / 30.0

    # ----------------------------------------------------------------------
    # 12) 🎯 几何终点特征（geo_*）
    # ----------------------------------------------------------------------
    # add_geometric_features() 内部会：
    # - 先用规则得到 geo_endpoint_x/y（目标接球者收敛落点、防守者镜像、其他动量外推）
    # - 再生成指向终点的向量、距离、所需速度/加速度、与当前速度对齐度等
    print("Step 5: 🎯 Geometric endpoint features...")
    input_df = add_geometric_features(input_df)

    print("Step 6: Building feature list...")

    # ----------------------------------------------------------------------
    # 13) 特征清单（每个特征都说明含义）
    # ----------------------------------------------------------------------
    # 说明：
    # - 这里把“手写基础特征”逐个注释清楚
    # - 对于批量生成的 lag/rolling/delta/ema，也会在列表外说明规则
    feature_cols = [
        # ====== 追踪原始字段 ======
        'x',                 # 球员 x 位置（场地长轴，0~120）
        'y',                 # 球员 y 位置（场地短轴，0~53.3）
        's',                 # 速度标量（码/秒）
        'a',                 # 加速度标量（码/秒^2）
        'o',                 # 身体朝向（度）
        'dir',               # 运动方向（度）
        'frame_id',          # 当前帧编号（10Hz 下每 +1 = 0.1 秒）
        'ball_land_x',       # 球落点 x（如果存在）
        'ball_land_y',       # 球落点 y（如果存在）

        # ====== 身体/体型 ======
        'player_height_feet',# 身高（英尺，小数）
        'player_weight',     # 体重（磅）
        'height_inches',     # 身高（英寸）
        'bmi',               # BMI（英制公式）

        # ====== 速度/加速度分量 ======
        'velocity_x',        # 速度 x 分量（由 s,dir 分解）
        'velocity_y',        # 速度 y 分量
        'acceleration_x',    # 加速度 x 分量
        'acceleration_y',    # 加速度 y 分量

        # ====== 动力学派生 ======
        'momentum_x',        # 动量 x（速度分量×体重）
        'momentum_y',        # 动量 y
        'kinetic_energy',    # 动能（0.5*weight*s^2）
        'speed_squared',     # s^2
        'accel_magnitude',   # ||加速度向量||
        'orientation_diff',  # |o-dir| 的最小环形差（0~180）

        # ====== 阵营/角色 one-hot ======
        'is_offense',              # 是否进攻方
        'is_defense',              # 是否防守方
        'is_receiver',             # 是否目标接球者
        'is_coverage',             # 是否防守覆盖者
        'is_passer',               # 是否四分卫/传球者
        'role_targeted_receiver',  # 同 is_receiver（语义化保留）
        'role_defensive_coverage', # 同 is_coverage
        'role_passer',             # 同 is_passer
        'side_offense',            # 同 is_offense（语义化保留）

        # ====== 与落点关系（ball geometry） ======
        'distance_to_ball',   # 到落点距离
        'dist_to_ball',       # 同 distance_to_ball（历史兼容）
        'dist_squared',       # 距离平方
        'angle_to_ball',      # 指向落点角（弧度）
        'ball_direction_x',   # 指向落点单位向量 x
        'ball_direction_y',   # 指向落点单位向量 y
        'closing_speed_ball', # 当前速度在指向落点方向的投影（>0 接近）
        'velocity_toward_ball',# 同类投影（另一种写法）
        'velocity_alignment', # 运动方向与指向落点方向夹角余弦
        'angle_diff',         # 身体朝向与指向落点方向的最小角差（度）

        # ====== 对手/镜像接球者（opponent / mirror） ======
        'nearest_opp_dist',   # 最近对手距离
        'closing_speed',      # 与最近对手的接近速度（>0 靠近）
        'num_nearby_opp_3',   # 3码内对手数
        'num_nearby_opp_5',   # 5码内对手数
        'mirror_wr_vx',       # 覆盖者的“镜像接球者”速度 x 分量
        'mirror_wr_vy',       # 镜像接球者速度 y 分量
        'mirror_offset_x',    # 覆盖者相对镜像接球者的 x 偏移
        'mirror_offset_y',    # 覆盖者相对镜像接球者的 y 偏移

        # ====== 压力与镜像相似 ======
        'pressure',           # 1 / nearest_opp_dist（越近压力越大）
        'under_pressure',     # nearest_opp_dist < 3 是否成立
        'pressure_x_speed',   # pressure * speed（交互项）
        'mirror_similarity',  # 覆盖者速度与镜像接球者速度相似度（近似内积归一）
        'mirror_offset_dist', # 覆盖者与镜像接球者偏移距离
        'mirror_alignment',   # mirror_similarity * is_coverage（只对覆盖者有效）

        # ====== 路线聚类（route pattern） ======
        'route_pattern',      # 路线簇 ID（KMeans 聚类结果）
        'traj_straightness',  # 轨迹直线性=位移/路程（越接近1越直）
        'traj_max_turn',      # 最大转向幅度（角度变化）
        'traj_mean_turn',     # 平均转向幅度
        'traj_depth',         # x 方向位移幅度（绝对值）
        'traj_width',         # y 方向位移幅度（绝对值）
        'speed_mean',         # 最近若干帧平均速度
        'speed_change',       # 速度变化（末-初）

        # ====== 邻域聚合（GNN-lite embedding） ======
        'gnn_ally_dx_mean',   # 友军相对位移 dx 的加权均值
        'gnn_ally_dy_mean',   # 友军相对位移 dy 的加权均值
        'gnn_ally_dvx_mean',  # 友军相对速度差 dvx 的加权均值
        'gnn_ally_dvy_mean',  # 友军相对速度差 dvy 的加权均值
        'gnn_opp_dx_mean',    # 对手相对位移 dx 的加权均值
        'gnn_opp_dy_mean',    # 对手相对位移 dy 的加权均值
        'gnn_opp_dvx_mean',   # 对手相对速度差 dvx 的加权均值
        'gnn_opp_dvy_mean',   # 对手相对速度差 dvy 的加权均值
        'gnn_ally_cnt',       # 邻域内友军数量（截断后）
        'gnn_opp_cnt',        # 邻域内对手数量
        'gnn_ally_dmin',      # 最近友军距离
        'gnn_ally_dmean',     # 友军平均距离
        'gnn_opp_dmin',       # 最近对手距离
        'gnn_opp_dmean',      # 对手平均距离
        'gnn_d1',             # 第1近邻距离
        'gnn_d2',             # 第2近邻距离
        'gnn_d3',             # 第3近邻距离
    ]

    # ====== 批量生成的特征（模板说明） ======
    # lag 特征：{col}_lag{1..5}
    # 例：x_lag3 = 3帧前的 x；velocity_y_lag1 = 上一帧的 velocity_y
    for lag in [1, 2, 3, 4, 5]:
        for col in ['x', 'y', 'velocity_x', 'velocity_y', 's', 'a']:
            feature_cols.append(f'{col}_lag{lag}')

    # rolling 统计：{col}_rolling_mean_{window}, {col}_rolling_std_{window}
    # 例：s_rolling_std_5 = 最近5帧速度的标准差
    for window in [3, 5]:
        for col in ['x', 'y', 'velocity_x', 'velocity_y', 's']:
            feature_cols.append(f'{col}_rolling_mean_{window}')
            feature_cols.append(f'{col}_rolling_std_{window}')

    # 差分：velocity_x_delta / velocity_y_delta（1阶差分）
    feature_cols.extend(['velocity_x_delta', 'velocity_y_delta'])

    # EMA：velocity_x_ema / velocity_y_ema / speed_ema（指数平滑）
    feature_cols.extend(['velocity_x_ema', 'velocity_y_ema', 'speed_ema'])

    # 时间/进度相关（如果列存在）
    feature_cols.extend([
        'max_play_duration',        # 未来总时长（秒）
        'frame_time',              # 当前帧时间（秒）
        'progress_ratio',          # 进度比例
        'time_remaining',          # 剩余时间（秒）
        'frames_remaining',        # 剩余帧数
        'expected_x_at_ball',      # 匀速外推 x
        'expected_y_at_ball',      # 匀速外推 y
        'error_from_ball_x',       # 外推误差 x
        'error_from_ball_y',       # 外推误差 y
        'error_from_ball',         # 外推误差距离
        'time_squared',            # 时间二次项
        'weighted_dist_by_time',   # 距离按时间惩罚
        'velocity_x_progress',     # v_x * progress
        'velocity_y_progress',     # v_y * progress
        'dist_scaled_by_progress', # 距离按 (1-progress) 缩放
        'speed_scaled_by_time_left',# speed * time_remaining
        'actual_play_length',      # 未来长度（帧）
        'length_ratio',            # 相对 30 帧的比例
    ])

    # 🎯 几何基线特征（geo_*）：围绕“规则终点”让模型学习偏差修正
    feature_cols.extend([
        'geo_endpoint_x',          # 规则终点 x
        'geo_endpoint_y',          # 规则终点 y
        'geo_vector_x',            # 指向终点向量 x（终点-当前位置）
        'geo_vector_y',            # 指向终点向量 y
        'geo_distance',            # 到终点距离
        'geo_required_vx',         # 平均所需速度 x（Δx / t）
        'geo_required_vy',         # 平均所需速度 y
        'geo_velocity_error_x',    # 所需速度 - 当前速度（x）
        'geo_velocity_error_y',    # 所需速度 - 当前速度（y）
        'geo_velocity_error',      # 速度误差模长
        'geo_required_ax',         # 匀加速到达所需 ax（2Δx/t^2）
        'geo_required_ay',         # 匀加速到达所需 ay
        'geo_alignment',           # 当前速度与指向终点方向的对齐度（cos相似）
    ])

    # 兼容训练/测试列差异：只保留实际存在的列
    feature_cols = [c for c in feature_cols if c in input_df.columns]
    print(f"✓ Using {len(feature_cols)} features (154 proven + 13 geometric)")

    print("Step 7: Creating sequences...")

    # ----------------------------------------------------------------------
    # 14) 构造样本序列（N 个球员样本，每个样本 T=window_size 帧）
    # ----------------------------------------------------------------------
    # 先把 (game_id, play_id, nfl_id) 设为索引，方便快速按球员取序列
    input_df.set_index(['game_id', 'play_id', 'nfl_id'], inplace=True)
    grouped = input_df.groupby(level=['game_id', 'play_id', 'nfl_id'])

    # 训练：以 output_df 中出现的球员为目标
    # 推理：以 test_template 中出现的球员为目标（因为 test_template 定义了要预测哪些人/帧）
    target_rows = output_df if is_training else test_template
    target_groups = target_rows[['game_id', 'play_id', 'nfl_id']].drop_duplicates()

    # sequences: list of [window_size, F]
    # targets_dx/dy: list of 不定长数组（每个球员未来帧数不同）
    sequences, targets_dx, targets_dy, targets_frame_ids, sequence_ids = [], [], [], [], []
    geo_endpoints_x, geo_endpoints_y = [], []

    for _, row in tqdm(target_groups.iterrows(), total=len(target_groups), desc="Creating sequences"):
        key = (row['game_id'], row['play_id'], row['nfl_id'])

        # 取出该球员在该 play 的全部传球前帧
        try:
            group_df = grouped.get_group(key)
        except KeyError:
            continue

        # 输入窗口：最后 window_size 帧（越靠近出手点越关键）
        input_window = group_df.tail(window_size)

        # 若不足 window_size：
        # - 训练：直接丢弃（避免信息太少导致噪声样本）
        # - 推理：允许，用 NaN padding 到固定长度
        if len(input_window) < window_size:
            if is_training:
                continue
            pad_len = window_size - len(input_window)
            pad_df = pd.DataFrame(np.nan, index=range(pad_len), columns=input_window.columns)
            input_window = pd.concat([pad_df, input_window], ignore_index=True)

        # 用该球员历史均值填 NaN（只对数值列），避免 scaler/模型输入出现缺失
        input_window = input_window.fillna(group_df.mean(numeric_only=True))

        # 取特征矩阵 [T, F]
        seq = input_window[feature_cols].values

        # 仍有 NaN：
        # - 训练：丢弃（质量控制）
        # - 推理：兜底用 0
        if np.isnan(seq).any():
            if is_training:
                continue
            seq = np.nan_to_num(seq, nan=0.0)

        sequences.append(seq)

        # 保存窗口最后一帧的几何终点（用于 debug/分析/可视化）
        geo_endpoints_x.append(input_window.iloc[-1]['geo_endpoint_x'])
        geo_endpoints_y.append(input_window.iloc[-1]['geo_endpoint_y'])

        # ---------------------------
        # 训练目标（相对位移序列）
        # ---------------------------
        if is_training:
            out_grp = output_df[
                (output_df['game_id'] == row['game_id']) &
                (output_df['play_id'] == row['play_id']) &
                (output_df['nfl_id'] == row['nfl_id'])
            ].sort_values('frame_id')

            # 输入窗口末帧作为“相对位移参考点”
            last_x = input_window.iloc[-1]['x']
            last_y = input_window.iloc[-1]['y']

            # dx/dy：未来每帧相对位移（与模型输出的 cumsum 对齐）
            dx = out_grp['x'].values - last_x
            dy = out_grp['y'].values - last_y

            targets_dx.append(dx)
            targets_dy.append(dy)
            targets_frame_ids.append(out_grp['frame_id'].values)

        # 保存该序列对应的标识：用于 GroupKFold 分组与生成 submission
        sequence_ids.append({
            'game_id': key[0],
            'play_id': key[1],
            'nfl_id': key[2],
            'frame_id': input_window.iloc[-1]['frame_id']  # 注意：这是输入窗口末帧
        })

    print(f"✓ Created {len(sequences)} sequences")

    # 训练阶段：额外返回 route_kmeans/route_scaler（推理阶段复用）
    if is_training:
        return (sequences, targets_dx, targets_dy, targets_frame_ids, sequence_ids, 
                geo_endpoints_x, geo_endpoints_y, route_kmeans, route_scaler)

    return sequences, sequence_ids, geo_endpoints_x, geo_endpoints_y

