1. 线上运行gnn-train.ipynb并save version，代码会输出GNN模型权重

2. 线上运行推理代码inference.ipynb，运行前加载第一步输出的GNN模型权重

后处理：将Tg*9/5+32（转化为华氏度），可直接到金牌区