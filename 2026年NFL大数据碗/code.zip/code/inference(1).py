import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm.auto import tqdm
import warnings
import os
import pickle

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from sklearn.cluster import KMeans

import sys
sys.path.append('/kaggle/input/nflexp') 

from utils import set_seed
from models import JointSeqModel, TemporalHuber
from data_fe import prepare_sequences_geometric

warnings.filterwarnings('ignore')  # 关闭告警输出，避免训练日志被打断

# ============================================================================
# 配置
# ============================================================================

class Config:
    DATA_DIR = Path("/kaggle/input/nfl-big-data-bowl-2026-prediction/")  # 数据根目录（Kaggle 输入挂载路径）
    model_dir = Path("/kaggle/input/nflexp")  # 本地输出目录（模型/特征等可落盘）
    
    SEED = 42
    N_FOLDS = 5
    BATCH_SIZE = 256
    EPOCHS = 200
    PATIENCE = 30  # 早停耐心：验证集连续不提升的 epoch 数阈值
    LEARNING_RATE = 1e-3  # AdamW 初始学习率
    
    WINDOW_SIZE = 10  # 输入序列长度：传球前最近 window_size 帧作为历史上下文
    HIDDEN_DIM = 128  # GRU 隐层维度
    MAX_FUTURE_HORIZON = 94  # 统一预测步长上限（按比赛最大 num_frames_output 对齐）
        
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 训练/推理设备选择


set_seed(Config.SEED)  # 全局设种子，确保后续流程可复现

config = Config()  # 读取配置

# 加载训练/测试数据（训练按周分文件）
test_input = pd.read_csv(config.DATA_DIR / "test_input.csv")
test_template = pd.read_csv(config.DATA_DIR / "test.csv")
print(f"✓ Test input: {test_input.shape}, Test template: {test_template.shape}")

# 读取模型与 scaler 列表
with open(f"{config.model_dir}/exp_models_scalers.pkl", "rb") as f:
    pick = pickle.load(f)
    models = pick["models"]
    scalers = pick["scalers"]

# 读取 route_kmeans 与 route_scaler
with open(f"{config.model_dir}/route_kmeans_scaler.pkl", "rb") as f:
    pick = pickle.load(f)
    route_kmeans = pick["route_kmeans"]
    route_scaler = pick["route_scaler"]


# 构造测试集序列并做集成预测
test_seq, test_ids, test_geo_x, test_geo_y = prepare_sequences_geometric(
    test_input, test_template=test_template, is_training=False, 
    window_size=config.WINDOW_SIZE,
    route_kmeans=route_kmeans, route_scaler=route_scaler
)

X_test = list(test_seq)  # 测试序列列表
x_last = np.array([s[-1, 0] for s in X_test])  # 使用特征列中 x 的位置（feature_cols 的第 0 列）
y_last = np.array([s[-1, 1] for s in X_test])  # 使用特征列中 y 的位置（feature_cols 的第 1 列）

# 多折模型集成：对每折分别标准化+推理，然后对预测取均值
all_preds = []

for model, sc in zip(models, scalers):
    X_sc = [sc.transform(s) for s in X_test]  # 按该折 scaler 标准化
    X_t = torch.tensor(np.stack(X_sc).astype(np.float32)).to(config.DEVICE)  # [N,T,F]
    
    model.eval()
    with torch.no_grad():
        preds = model(X_t).cpu().numpy()  # [N,H,2]：相对位移预测
    
    all_preds.append(preds)

ens_preds = np.mean(all_preds, axis=0)  # [N,H,2]：折均值集成

# 生成提交文件：对每个 (game, play, player) 的所有需要预测 frame_id 输出 x/y
rows = []
H = ens_preds.shape[1]  # 预测 horizon

for i, sid in enumerate(test_ids):
    fids = test_template[
        (test_template['game_id'] == sid['game_id']) &
        (test_template['play_id'] == sid['play_id']) &
        (test_template['nfl_id'] == sid['nfl_id'])
    ]['frame_id'].sort_values().tolist()
    
    # 对该球员的每个目标帧，取对应步长的相对位移（超出 horizon 则截断用最后一步）
    for t, fid in enumerate(fids):
        tt = min(t, H - 1)
        px = np.clip(x_last[i] + ens_preds[i, tt, 0], 0, 120)  # 绝对 x=最后输入 x + 预测相对位移
        py = np.clip(y_last[i] + ens_preds[i, tt, 1], 0, 53.3)  # 绝对 y=最后输入 y + 预测相对位移
        
        rows.append({
            'id': f"{sid['game_id']}_{sid['play_id']}_{sid['nfl_id']}_{fid}",
            'x': px,
            'y': py
        })

submission = pd.DataFrame(rows)  # 汇总为提交表
submission.to_csv("submission.csv", index=False)  # 写出到当前目录